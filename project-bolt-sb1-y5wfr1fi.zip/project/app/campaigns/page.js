'use client';

import { useEffect, useState } from 'react';
import { Plus, Trophy, Users as UsersIcon, Calendar } from 'lucide-react';
import Loading from '@/components/Loading';
import ErrorState from '@/components/ErrorState';
import { showToast } from '@/components/Toast';

export default function CampaignsPage() {
  const [campaigns, setCampaigns] = useState([]);
  const [participants, setParticipants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [formData, setFormData] = useState({ title: '', description: '', type: 'event' });

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [campaignsRes, participantsRes] = await Promise.all([
        fetch('/api/campaigns'),
        fetch('/api/participants'),
      ]);
      const [campaignsData, participantsData] = await Promise.all([
        campaignsRes.json(),
        participantsRes.json(),
      ]);
      if (campaignsData.error) throw new Error(campaignsData.error);
      setCampaigns(campaignsData.data || []);
      setParticipants(participantsData.data || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/campaigns', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      showToast('Campaign created successfully!', 'success');
      setShowModal(false);
      setFormData({ title: '', description: '', type: 'event' });
      fetchData();
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  const getParticipantCount = (campaignId) => {
    return participants.filter(p => p.campaign_id === campaignId).length;
  };

  if (loading) return <Loading text="Loading Campaigns..." />;
  if (error) return <ErrorState message={error} retry={fetchData} />;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600 mb-2">
            CAMPAIGNS
          </h1>
          <p className="text-gray-400">{campaigns.length} total campaigns</p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-bold rounded-lg shadow-lg shadow-purple-500/50 transition-all"
        >
          <Plus className="w-5 h-5" />
          New Campaign
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {campaigns.map(campaign => (
          <div
            key={campaign.id}
            className="p-6 rounded-xl border border-purple-500/30 bg-purple-500/5 backdrop-blur-xl hover:bg-purple-500/10 transition-all cursor-pointer"
            onClick={() => setSelectedCampaign(campaign)}
          >
            <div className="flex items-start justify-between mb-4">
              <Trophy className="w-8 h-8 text-purple-400" />
              <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                campaign.status === 'active' ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'
              }`}>
                {campaign.status || 'draft'}
              </span>
            </div>
            <h3 className="text-xl font-black text-white mb-2">{campaign.title}</h3>
            <p className="text-sm text-gray-400 mb-4 line-clamp-2">{campaign.description || 'No description'}</p>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2 text-purple-400">
                <UsersIcon className="w-4 h-4" />
                <span className="font-bold">{getParticipantCount(campaign.id)} participants</span>
              </div>
              <div className="flex items-center gap-2 text-gray-500">
                <Calendar className="w-4 h-4" />
                <span>{new Date(campaign.created_at).toLocaleDateString()}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-gray-900 border border-purple-500/30 rounded-xl p-8 max-w-md w-full mx-4">
            <h2 className="text-2xl font-black text-purple-400 mb-6 flex items-center gap-2">
              <Trophy className="w-6 h-6" />
              Create Campaign
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-400 mb-2">Title</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-4 py-2 bg-black/50 border border-purple-500/30 rounded-lg text-white focus:outline-none focus:border-purple-500"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-400 mb-2">Description</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 bg-black/50 border border-purple-500/30 rounded-lg text-white focus:outline-none focus:border-purple-500"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-400 mb-2">Type</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  className="w-full px-4 py-2 bg-black/50 border border-purple-500/30 rounded-lg text-white focus:outline-none focus:border-purple-500"
                >
                  <option value="event">Event</option>
                  <option value="tournament">Tournament</option>
                  <option value="mission">Mission</option>
                  <option value="challenge">Challenge</option>
                </select>
              </div>
              <div className="flex gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white font-bold rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-bold rounded-lg transition-all"
                >
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {selectedCampaign && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50" onClick={() => setSelectedCampaign(null)}>
          <div className="bg-gray-900 border border-purple-500/30 rounded-xl p-8 max-w-2xl w-full mx-4" onClick={(e) => e.stopPropagation()}>
            <h2 className="text-2xl font-black text-purple-400 mb-4">{selectedCampaign.title}</h2>
            <p className="text-gray-300 mb-6">{selectedCampaign.description}</p>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="p-4 bg-black/50 rounded-lg border border-purple-500/30">
                <div className="text-sm text-gray-400 mb-1">Status</div>
                <div className="text-lg font-bold text-white">{selectedCampaign.status}</div>
              </div>
              <div className="p-4 bg-black/50 rounded-lg border border-purple-500/30">
                <div className="text-sm text-gray-400 mb-1">Type</div>
                <div className="text-lg font-bold text-white">{selectedCampaign.type}</div>
              </div>
              <div className="p-4 bg-black/50 rounded-lg border border-purple-500/30">
                <div className="text-sm text-gray-400 mb-1">Participants</div>
                <div className="text-lg font-bold text-purple-400">{getParticipantCount(selectedCampaign.id)}</div>
              </div>
              <div className="p-4 bg-black/50 rounded-lg border border-purple-500/30">
                <div className="text-sm text-gray-400 mb-1">Created</div>
                <div className="text-lg font-bold text-white">{new Date(selectedCampaign.created_at).toLocaleDateString()}</div>
              </div>
            </div>
            <button
              onClick={() => setSelectedCampaign(null)}
              className="w-full px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white font-bold rounded-lg transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
