'use client';

import { useEffect, useState } from 'react';
import { Users, Trophy, MessageSquare, DollarSign, TrendingUp } from 'lucide-react';
import Loading from '@/components/Loading';
import ErrorState from '@/components/ErrorState';

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchStats = async () => {
    setLoading(true);
    setError(null);
    try {
      const [usersRes, campaignsRes, threadsRes, transactionsRes] = await Promise.all([
        fetch('/api/users'),
        fetch('/api/campaigns'),
        fetch('/api/threads'),
        fetch('/api/transactions'),
      ]);

      const [users, campaigns, threads, transactions] = await Promise.all([
        usersRes.json(),
        campaignsRes.json(),
        threadsRes.json(),
        transactionsRes.json(),
      ]);

      const totalAmount = transactions.data?.reduce((sum, t) => sum + parseFloat(t.amount || 0), 0) || 0;

      setStats({
        users: users.data?.length || 0,
        campaigns: campaigns.data?.length || 0,
        threads: threads.data?.length || 0,
        transactions: transactions.data?.length || 0,
        totalAmount,
      });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  if (loading) return <Loading text="Loading Dashboard..." />;
  if (error) return <ErrorState message={error} retry={fetchStats} />;

  const cards = [
    {
      title: 'Total Users',
      value: stats.users,
      icon: Users,
      color: 'from-cyan-500 to-blue-600',
      bgColor: 'bg-cyan-500/10',
      borderColor: 'border-cyan-500/30',
    },
    {
      title: 'Active Campaigns',
      value: stats.campaigns,
      icon: Trophy,
      color: 'from-purple-500 to-pink-600',
      bgColor: 'bg-purple-500/10',
      borderColor: 'border-purple-500/30',
    },
    {
      title: 'Chat Threads',
      value: stats.threads,
      icon: MessageSquare,
      color: 'from-green-500 to-emerald-600',
      bgColor: 'bg-green-500/10',
      borderColor: 'border-green-500/30',
    },
    {
      title: 'Transactions',
      value: stats.transactions,
      icon: DollarSign,
      color: 'from-orange-500 to-red-600',
      bgColor: 'bg-orange-500/10',
      borderColor: 'border-orange-500/30',
    },
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-600 mb-2">
          DASHBOARD
        </h1>
        <p className="text-gray-400">System overview and statistics</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {cards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div
              key={index}
              className={`relative p-6 rounded-xl border ${card.borderColor} ${card.bgColor} backdrop-blur-xl overflow-hidden group hover:scale-105 transition-transform`}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${card.color} opacity-0 group-hover:opacity-10 transition-opacity`}></div>
              <div className="relative z-10">
                <div className="flex items-center justify-between mb-4">
                  <Icon className="w-8 h-8 text-gray-400" />
                  <TrendingUp className="w-5 h-5 text-green-400" />
                </div>
                <div className={`text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r ${card.color} mb-2`}>
                  {card.value.toLocaleString()}
                </div>
                <div className="text-sm text-gray-400 font-bold uppercase tracking-wide">
                  {card.title}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="p-6 rounded-xl border border-cyan-500/30 bg-cyan-500/10 backdrop-blur-xl">
          <h2 className="text-2xl font-black text-cyan-400 mb-4">TOTAL VALUE</h2>
          <div className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-600">
            {stats.totalAmount.toLocaleString('en-US', {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2
            })} THB
          </div>
        </div>

        <div className="p-6 rounded-xl border border-cyan-500/30 bg-cyan-500/10 backdrop-blur-xl">
          <h2 className="text-2xl font-black text-cyan-400 mb-4">SYSTEM STATUS</h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Database</span>
              <span className="px-3 py-1 rounded-full bg-green-500/20 text-green-400 text-sm font-bold">ONLINE</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400">API</span>
              <span className="px-3 py-1 rounded-full bg-green-500/20 text-green-400 text-sm font-bold">ONLINE</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Services</span>
              <span className="px-3 py-1 rounded-full bg-green-500/20 text-green-400 text-sm font-bold">OPERATIONAL</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
