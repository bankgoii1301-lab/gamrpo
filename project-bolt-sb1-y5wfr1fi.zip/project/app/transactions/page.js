'use client';

import { useEffect, useState } from 'react';
import { Plus, DollarSign, TrendingUp, TrendingDown, Filter } from 'lucide-react';
import Loading from '@/components/Loading';
import ErrorState from '@/components/ErrorState';
import { showToast } from '@/components/Toast';

export default function TransactionsPage() {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [filterType, setFilterType] = useState('all');
  const [formData, setFormData] = useState({
    user_id: '',
    type: 'reward',
    amount: '',
    description: '',
  });

  const fetchTransactions = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/transactions');
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setTransactions(data.data || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      showToast('Transaction created successfully!', 'success');
      setShowModal(false);
      setFormData({ user_id: '', type: 'reward', amount: '', description: '' });
      fetchTransactions();
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  const filteredTransactions = filterType === 'all'
    ? transactions
    : transactions.filter(t => t.type === filterType);

  const totalAmount = filteredTransactions.reduce((sum, t) => sum + parseFloat(t.amount || 0), 0);

  if (loading) return <Loading text="Loading Transactions..." />;
  if (error) return <ErrorState message={error} retry={fetchTransactions} />;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-red-600 mb-2">
            TRANSACTIONS
          </h1>
          <p className="text-gray-400">{transactions.length} total transactions</p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-bold rounded-lg shadow-lg shadow-orange-500/50 transition-all"
        >
          <Plus className="w-5 h-5" />
          New Transaction
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="p-6 rounded-xl border border-orange-500/30 bg-orange-500/10 backdrop-blur-xl">
          <div className="text-sm text-gray-400 mb-2">TOTAL AMOUNT</div>
          <div className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-red-600">
            {totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })} THB
          </div>
        </div>
        <div className="p-6 rounded-xl border border-green-500/30 bg-green-500/10 backdrop-blur-xl">
          <div className="text-sm text-gray-400 mb-2">INCOME</div>
          <div className="text-3xl font-black text-green-400">
            {transactions
              .filter(t => ['deposit', 'reward'].includes(t.type))
              .reduce((sum, t) => sum + parseFloat(t.amount || 0), 0)
              .toLocaleString('en-US', { minimumFractionDigits: 2 })} THB
          </div>
        </div>
        <div className="p-6 rounded-xl border border-red-500/30 bg-red-500/10 backdrop-blur-xl">
          <div className="text-sm text-gray-400 mb-2">EXPENSES</div>
          <div className="text-3xl font-black text-red-400">
            {transactions
              .filter(t => ['withdrawal', 'penalty'].includes(t.type))
              .reduce((sum, t) => sum + parseFloat(t.amount || 0), 0)
              .toLocaleString('en-US', { minimumFractionDigits: 2 })} THB
          </div>
        </div>
      </div>

      <div className="mb-6 flex gap-3">
        <button
          onClick={() => setFilterType('all')}
          className={`px-4 py-2 rounded-lg font-bold transition-all ${
            filterType === 'all'
              ? 'bg-gradient-to-r from-orange-500 to-red-600 text-white'
              : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
          }`}
        >
          All
        </button>
        {['deposit', 'withdrawal', 'reward', 'penalty', 'refund'].map(type => (
          <button
            key={type}
            onClick={() => setFilterType(type)}
            className={`px-4 py-2 rounded-lg font-bold transition-all capitalize ${
              filterType === type
                ? 'bg-gradient-to-r from-orange-500 to-red-600 text-white'
                : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
            }`}
          >
            {type}
          </button>
        ))}
      </div>

      <div className="grid gap-4">
        {filteredTransactions.map(transaction => {
          const isPositive = ['deposit', 'reward'].includes(transaction.type);
          return (
            <div
              key={transaction.id}
              className="p-6 rounded-xl border border-orange-500/30 bg-orange-500/5 backdrop-blur-xl hover:bg-orange-500/10 transition-colors"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    isPositive ? 'bg-green-500/20' : 'bg-red-500/20'
                  }`}>
                    {isPositive ? (
                      <TrendingUp className="w-6 h-6 text-green-400" />
                    ) : (
                      <TrendingDown className="w-6 h-6 text-red-400" />
                    )}
                  </div>
                  <div>
                    <div className="text-lg font-bold text-white">
                      {transaction.user?.username || 'Unknown User'}
                    </div>
                    <div className="text-sm text-gray-400">{transaction.description || 'No description'}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className={`text-2xl font-black ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
                    {isPositive ? '+' : '-'}{parseFloat(transaction.amount || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })} THB
                  </div>
                  <div className="flex items-center gap-3 mt-1">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                      transaction.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                      transaction.status === 'failed' ? 'bg-red-500/20 text-red-400' :
                      'bg-yellow-500/20 text-yellow-400'
                    }`}>
                      {transaction.status}
                    </span>
                    <span className="text-sm text-gray-500">
                      {new Date(transaction.created_at).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-gray-900 border border-orange-500/30 rounded-xl p-8 max-w-md w-full mx-4">
            <h2 className="text-2xl font-black text-orange-400 mb-6 flex items-center gap-2">
              <DollarSign className="w-6 h-6" />
              New Transaction
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-400 mb-2">User ID</label>
                <input
                  type="text"
                  required
                  value={formData.user_id}
                  onChange={(e) => setFormData({ ...formData, user_id: e.target.value })}
                  className="w-full px-4 py-2 bg-black/50 border border-orange-500/30 rounded-lg text-white focus:outline-none focus:border-orange-500"
                  placeholder="Enter user ID"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-400 mb-2">Type</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  className="w-full px-4 py-2 bg-black/50 border border-orange-500/30 rounded-lg text-white focus:outline-none focus:border-orange-500"
                >
                  <option value="deposit">Deposit</option>
                  <option value="withdrawal">Withdrawal</option>
                  <option value="reward">Reward</option>
                  <option value="penalty">Penalty</option>
                  <option value="refund">Refund</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-400 mb-2">Amount</label>
                <input
                  type="number"
                  required
                  step="0.01"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  className="w-full px-4 py-2 bg-black/50 border border-orange-500/30 rounded-lg text-white focus:outline-none focus:border-orange-500"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-400 mb-2">Description</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 bg-black/50 border border-orange-500/30 rounded-lg text-white focus:outline-none focus:border-orange-500"
                />
              </div>
              <div className="flex gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white font-bold rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-bold rounded-lg transition-all"
                >
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
