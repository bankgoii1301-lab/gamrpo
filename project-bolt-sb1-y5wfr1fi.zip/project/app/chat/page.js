'use client';

import { useEffect, useState } from 'react';
import { MessageSquare, Send } from 'lucide-react';
import Loading from '@/components/Loading';
import ErrorState from '@/components/ErrorState';
import { showToast } from '@/components/Toast';

export default function ChatPage() {
  const [threads, setThreads] = useState([]);
  const [messages, setMessages] = useState([]);
  const [selectedThread, setSelectedThread] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [messageText, setMessageText] = useState('');

  const fetchThreads = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/threads');
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setThreads(data.data || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchMessages = async (threadId) => {
    try {
      const res = await fetch(`/api/messages?thread_id=${threadId}`);
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setMessages(data.data || []);
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  useEffect(() => {
    fetchThreads();
  }, []);

  useEffect(() => {
    if (selectedThread) {
      fetchMessages(selectedThread.id);
      const interval = setInterval(() => fetchMessages(selectedThread.id), 3000);
      return () => clearInterval(interval);
    }
  }, [selectedThread]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!messageText.trim() || !selectedThread) return;

    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          thread_id: selectedThread.id,
          sender_id: selectedThread.created_by,
          content: messageText,
        }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setMessageText('');
      fetchMessages(selectedThread.id);
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  if (loading) return <Loading text="Loading Chat..." />;
  if (error) return <ErrorState message={error} retry={fetchThreads} />;

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-600 mb-8">
        CHAT SYSTEM
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-220px)]">
        <div className="lg:col-span-1 p-4 rounded-xl border border-green-500/30 bg-green-500/5 backdrop-blur-xl overflow-y-auto">
          <h2 className="text-xl font-black text-green-400 mb-4">THREADS</h2>
          <div className="space-y-2">
            {threads.map(thread => (
              <div
                key={thread.id}
                onClick={() => setSelectedThread(thread)}
                className={`p-4 rounded-lg cursor-pointer transition-all ${
                  selectedThread?.id === thread.id
                    ? 'bg-green-500/20 border border-green-500'
                    : 'bg-black/30 border border-green-500/20 hover:bg-green-500/10'
                }`}
              >
                <div className="flex items-start gap-3">
                  <MessageSquare className="w-5 h-5 text-green-400 mt-1" />
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-white truncate">{thread.title || 'Untitled'}</div>
                    <div className="text-xs text-gray-500 mt-1">
                      {new Date(thread.created_at).toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>
            ))}
            {threads.length === 0 && (
              <div className="text-center text-gray-500 py-8">No threads available</div>
            )}
          </div>
        </div>

        <div className="lg:col-span-2 flex flex-col rounded-xl border border-green-500/30 bg-green-500/5 backdrop-blur-xl overflow-hidden">
          {selectedThread ? (
            <>
              <div className="p-4 border-b border-green-500/30 bg-black/30">
                <h3 className="text-xl font-black text-green-400">{selectedThread.title}</h3>
                <p className="text-sm text-gray-400">
                  {selectedThread.created_by_user?.username || 'Unknown user'}
                </p>
              </div>

              <div className="flex-1 p-4 overflow-y-auto space-y-4">
                {messages.map(message => (
                  <div key={message.id} className="flex gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center text-white font-black flex-shrink-0">
                      {message.sender?.username?.[0]?.toUpperCase() || 'U'}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-bold text-white">{message.sender?.username || 'Unknown'}</span>
                        <span className="text-xs text-gray-500">
                          {new Date(message.created_at).toLocaleString()}
                        </span>
                      </div>
                      <div className="p-3 rounded-lg bg-black/50 border border-green-500/20 text-gray-300">
                        {message.content}
                      </div>
                    </div>
                  </div>
                ))}
                {messages.length === 0 && (
                  <div className="text-center text-gray-500 py-12">No messages yet</div>
                )}
              </div>

              <form onSubmit={handleSendMessage} className="p-4 border-t border-green-500/30 bg-black/30">
                <div className="flex gap-3">
                  <input
                    type="text"
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    placeholder="Type a message..."
                    className="flex-1 px-4 py-2 bg-black/50 border border-green-500/30 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-green-500"
                  />
                  <button
                    type="submit"
                    disabled={!messageText.trim()}
                    className="px-6 py-2 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold rounded-lg transition-all flex items-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    Send
                  </button>
                </div>
              </form>
            </>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-500">
              Select a thread to view messages
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
