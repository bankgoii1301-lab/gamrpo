import './globals.css';
import Navbar from '@/components/Navbar';
import Toast from '@/components/Toast';

export const metadata = {
  title: 'Admin Panel - Gaming System',
  description: 'Powerful admin dashboard with gaming aesthetics',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="antialiased">
        <Navbar />
        <main className="min-h-screen">
          {children}
        </main>
        <Toast />
      </body>
    </html>
  );
}
