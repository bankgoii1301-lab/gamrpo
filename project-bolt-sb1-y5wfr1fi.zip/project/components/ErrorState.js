import { AlertCircle } from 'lucide-react';

export default function ErrorState({ message = 'Something went wrong', retry }) {
  return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="text-center max-w-md">
        <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h3 className="text-xl font-bold text-red-400 mb-2">Error</h3>
        <p className="text-gray-400 mb-4">{message}</p>
        {retry && (
          <button
            onClick={retry}
            className="px-6 py-2 bg-red-500 hover:bg-red-600 text-white font-bold rounded-lg transition-colors"
          >
            Try Again
          </button>
        )}
      </div>
    </div>
  );
}
